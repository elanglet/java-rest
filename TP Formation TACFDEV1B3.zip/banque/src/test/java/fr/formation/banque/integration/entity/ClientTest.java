package fr.formation.banque.integration.entity;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import static org.assertj.core.api.Assertions.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

public class ClientTest {

	private Client client;
	
	@Before
	public void setUp() throws Exception {
		client = new Client();
		client.setId(1);
		client.setNom("DUPONT");
		client.setPrenom("Robert");
		client.setAdresse("40 rue de la Paix");
		client.setCodePostal("44300");
		client.setVille("Nantes");
		client.setMotDePasse("secret");
	}

	@Test
	public void testClient() {
		Client client = new Client();
		assertNotNull(client);
	}

	@Test
	public void testGetId() {
		assertEquals(1, client.getId());
	}

	@Test
	public void testSetId() {
		client.setId(22);
		assertEquals(22, client.getId());
	}

	@Test
	public void testGetNom() {
		assertEquals("DUPONT", client.getNom());
	}

	@Test
	public void testSetNom() {
		client.setNom("DURAND");
		assertEquals("DURAND", client.getNom());
	}

	@Test
	public void testGetPrenom() {
		assertEquals("Robert", client.getPrenom());
	}

	@Test
	public void testSetPrenom() {
		client.setPrenom("Eric");
		assertEquals("Eric", client.getPrenom());
	}

	@Test
	public void testGetAdresse() {
		assertEquals("40 rue de la Paix", client.getAdresse());
	}

	@Test
	public void testSetAdresse() {
		client.setAdresse("Place Mellinet");
		assertEquals("Place Mellinet", client.getAdresse());
	}

	@Test
	public void testGetCodePostal() {
		assertEquals("44300", client.getCodePostal());
	}

	@Test
	public void testSetCodePostal() {
		client.setCodePostal("44100");
		assertEquals("44100", client.getCodePostal());
	}

	@Test
	public void testGetVille() {
		assertEquals("Nantes", client.getVille());
	}

	@Test
	public void testSetVille() {
		client.setVille("NANTES");
		assertEquals("NANTES", client.getVille());
	}

	@Test
	public void testGetMotDePasse() {
		assertEquals("secret", client.getMotDePasse());
	}

	@Test
	public void testSetMotDePasse() {
		client.setMotDePasse("password");
		assertEquals("password", client.getMotDePasse());
	}

}
