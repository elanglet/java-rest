package fr.formation.banque.integration.dao;

import static org.junit.Assert.*;

import static org.mockito.Mockito.*;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import fr.formation.banque.integration.entity.Client;
import fr.formation.banque.util.BanqueException;

public class HibernateClientDAOTest {

	// 1. D�claration des Mocks : Les objets � simuler.
	// Ici il s'agit des objets d'Hibernate
	@Mock
	private SessionFactory sessionFactory;
	@Mock
	private Session session;
	
	// 2. On injecte les Mocks dans l'objet � tester
	//		C'est le bouchonnage !
	@InjectMocks
	private HibernateClientDAO clientDAO;

	@Before
	public void setUp() throws Exception {	
		// On demande � Mockito de tenir compte des annotations
		MockitoAnnotations.initMocks(this);
	}


	@Test
	public void testSetSessionFactory() {
	}

	@Test
	public void testAjouterClient() {
		try {
			// 3. On d�crit le comportement de la m�thode � tester avec 'when'
			when(sessionFactory.getCurrentSession()).thenReturn(session);
			
			// 4. On invoque la m�thode � tester
			Client client = new Client();
			client.setId(1);
			client.setNom("DUPONT");
			client.setPrenom("Robert");
			client.setAdresse("40 rue de la Paix");
			client.setCodePostal("44300");
			client.setVille("Nantes");
			client.setMotDePasse("secret");
			
			clientDAO.ajouterClient(client);
			
			// 5. On v�rifie les invocations avec 'verify
			// On v�rifie que la m�thode persist() de la session a bien �t� 
			// invoqu�e avec l'objet client en param�tre
			verify( sessionFactory.getCurrentSession() ).persist(client);
			
		} 
		catch (Exception e) {
			fail(e.getClass().getName() + ": " + e.getMessage());
		}
	}

	@Test
	public void testRechercherClientParId() {
		try {
			// 3. Description avec when
			Client client = new Client();
			client.setId(1);
			client.setNom("DUPONT");
			client.setPrenom("Robert");
			client.setAdresse("40 rue de la Paix");
			client.setCodePostal("44300");
			client.setVille("Nantes");
			client.setMotDePasse("secret");
			
			when(sessionFactory.getCurrentSession()).thenReturn(session);
			when(session.load(Client.class, 1L)).thenReturn(client);
			
			// 4. Invoquer la m�thode
			Client leClient = clientDAO.rechercherClientParId(1);
			assertNotNull(leClient);
			assertEquals(1, leClient.getId());
			// ... 
			
			// 5. V�rification
			verify(session).load(Client.class, 1L);
		} 
		catch (Exception e) {
			fail(e.getClass().getName() + ": " + e.getMessage());
		}
	}

	@Test
	public void testRechercherTousLesClients() { }

	@Test
	public void testRechercherClientsParNomEtPrenom() { }

	@Test
	public void testModifierClient() {
		try {
			// 3. On d�crit le comportement de la m�thode � tester avec 'when'
			when(sessionFactory.getCurrentSession()).thenReturn(session);
			
			// 4. On invoque la m�thode � tester
			Client client = new Client();
			client.setId(1);
			client.setNom("DUPONT");
			client.setPrenom("Robert");
			client.setAdresse("40 rue de la Paix");
			client.setCodePostal("44300");
			client.setVille("Nantes");
			client.setMotDePasse("secret");
			
			clientDAO.modifierClient(client);
			
			// 5. On v�rifie les invocations avec 'verify
			verify(session).merge(client);
			
		} 
		catch (Exception e) {
			fail(e.getClass().getName() + ": " + e.getMessage());
		}
	}

}
