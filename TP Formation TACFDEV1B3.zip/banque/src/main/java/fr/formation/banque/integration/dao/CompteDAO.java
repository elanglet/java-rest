package fr.formation.banque.integration.dao;

import java.util.List;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import fr.formation.banque.integration.entity.Client;
import fr.formation.banque.integration.entity.Compte;
import fr.formation.banque.util.BanqueException;

public interface CompteDAO {

	@Transactional(value=TxType.REQUIRED, rollbackOn = BanqueException.class)
	public abstract void ajouterCompte(Compte compte) throws BanqueException;
	
	@Transactional(value=TxType.REQUIRED, rollbackOn = BanqueException.class)
	public abstract void modifierCompte(Compte compte) throws BanqueException;
	
	@Transactional(value=TxType.REQUIRED, rollbackOn = BanqueException.class)
	public abstract void supprimerCompte(Compte compte) throws BanqueException;
	
	@Transactional(value=TxType.REQUIRED, rollbackOn = BanqueException.class)
	public abstract Compte rechercherCompteParNumero(long numero) throws BanqueException;
	
	@Transactional(value=TxType.REQUIRED, rollbackOn = BanqueException.class)
	public abstract List<Compte> rechercherComptesClient(Client client) throws BanqueException;
	
	@Transactional(value=TxType.REQUIRED, rollbackOn = BanqueException.class)
	public abstract List<Compte> rechercherComptesDebiteurs() throws BanqueException;
}
