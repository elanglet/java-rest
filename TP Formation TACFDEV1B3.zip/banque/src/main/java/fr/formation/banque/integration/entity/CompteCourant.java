package fr.formation.banque.integration.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="comptecourant")
@PrimaryKeyJoinColumn(name="idcomptecourant")
public class CompteCourant extends Compte {

	@Column(name="autorisation", precision=10, scale=2)
	private double autorisation;

	public double getAutorisation() {
		return autorisation;
	}

	public void setAutorisation(double autorisation) {
		this.autorisation = autorisation;
	}

}
