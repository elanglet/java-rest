package fr.formation.banque.presentation;

import java.io.Serializable;

public class VirementForm implements Serializable {

	private String debiter;
	private String crediter;
	private String montant;

	public String getDebiter() {
		return debiter;
	}

	public void setDebiter(String debiter) {
		this.debiter = debiter;
	}

	public String getCrediter() {
		return crediter;
	}

	public void setCrediter(String crediter) {
		this.crediter = crediter;
	}

	public String getMontant() {
		return montant;
	}

	public void setMontant(String montant) {
		this.montant = montant;
	}

}
