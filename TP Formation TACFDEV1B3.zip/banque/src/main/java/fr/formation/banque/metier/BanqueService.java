package fr.formation.banque.metier;

import java.util.List;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import fr.formation.banque.integration.entity.Client;
import fr.formation.banque.integration.entity.Compte;
import fr.formation.banque.util.BanqueException;

public interface BanqueService {

	@Transactional(value=TxType.SUPPORTS, rollbackOn=BanqueException.class)
	public abstract Client authentifier(long id, String motDePasse) throws BanqueException;
	
	@Transactional(value=TxType.SUPPORTS, rollbackOn=BanqueException.class)
	public abstract List<Compte> mesComptes(long idClient) throws BanqueException;
	
	@Transactional(value=TxType.REQUIRES_NEW, rollbackOn=BanqueException.class)
	public abstract void virementEntreComptes(
		long numeroCompteADebiter, long numeroCompteACrediter, double montant	
	) throws BanqueException;
	
}
