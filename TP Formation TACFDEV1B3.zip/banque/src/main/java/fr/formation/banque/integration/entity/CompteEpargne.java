package fr.formation.banque.integration.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="compteepargne")
@PrimaryKeyJoinColumn(name="idcompteepargne")
public class CompteEpargne extends Compte {

	@Column(name="taux", precision=3, scale=2)
	private double taux;

	public double getTaux() {
		return taux;
	}

	public void setTaux(double taux) {
		this.taux = taux;
	}

}
