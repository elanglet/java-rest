package fr.formation.banque.presentation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import fr.formation.banque.integration.entity.Client;
import fr.formation.banque.integration.entity.Compte;
import fr.formation.banque.metier.BanqueService;

@Controller
@SessionAttributes({ "leClient" })
public class IdentificationController {

	// Injection du banqueService
	@Autowired
	private BanqueService banqueService;
	
	// Methode d'affichage du formulaire
	@RequestMapping(
		value="/identification.do", 
		method=RequestMethod.GET
	)
	public String showForm() {
		return "identification";
	}
	
	// M�thode d'initialisation du bean de formulaire
	@ModelAttribute("identificationForm")
	public IdentificationForm initForm() {
		IdentificationForm form = new IdentificationForm();
				
		return form;
	}

	// M�thode de traitement du formulaire
	@RequestMapping(method=RequestMethod.POST)
	public String submitForm(
		@ModelAttribute("identificationForm") IdentificationForm idForm,
		ModelMap model
	) {
		try {
			long identifiant = Long.parseLong(idForm.getIdentifiant());
			String motDePasse = idForm.getMotDePasse();
			
			// Traitements ...
			Client client = banqueService.authentifier(identifiant, motDePasse);
			List<Compte> listeComptes = banqueService.mesComptes(client.getId());
			
			// On transmet les donn�es � la vue
			model.addAttribute("leClient", client);
			model.addAttribute("lesComptes", listeComptes);
			
			return "comptes";
		}
		catch(Exception e) {
			e.printStackTrace();
			model.addAttribute("message", "Erreur d'authentification");			
			return "identification";
		}
	}
	
}
