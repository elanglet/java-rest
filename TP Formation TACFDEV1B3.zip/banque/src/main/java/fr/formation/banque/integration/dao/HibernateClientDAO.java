package fr.formation.banque.integration.dao;

import java.util.List;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import fr.formation.banque.integration.entity.Client;
import fr.formation.banque.util.BanqueException;

public class HibernateClientDAO implements ClientDAO {
	
	// D�finition du Logger Log4J
	private static Logger log = LogManager.getLogger(HibernateClientDAO.class);
	
	// R�f�rence � la SessionFactory
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void ajouterClient(Client client) throws BanqueException {
		try {
			sessionFactory.getCurrentSession().persist(client);
			log.info("La création du nouveau client a réussi.");
			log.debug("Client enregistré : " + client.getId());
		} 
		catch (HibernateException e) {
			log.catching(Level.ERROR, e);
			throw new BanqueException("Erreur lors de l'enregistrement du client.");
		}
	}

	public Client rechercherClientParId(long id) throws BanqueException {
		try {
			log.debug("Client d'id " + id + " récupéré.");
			return sessionFactory.getCurrentSession().load(Client.class, id);
		} 
		catch (HibernateException e) {
			log.catching(Level.ERROR, e);
			throw new BanqueException("Erreur lors de la récupération du client.");
		}
	}

	public List<Client> rechercherTousLesClients() throws BanqueException {
		try {
			Query<Client> q = sessionFactory.getCurrentSession().createQuery("from Client", Client.class);
			log.debug("Liste des clients récupérée.");
			return q.list();
		} 
		catch (HibernateException e) {
			log.catching(Level.ERROR, e);
			throw new BanqueException("Erreur lors de la récupération de la liste des clients.");
		}
	}

	public List<Client> rechercherClientsParNomEtPrenom(String nom, String prenom) throws BanqueException {
		try {
			Query<Client> q = sessionFactory.getCurrentSession().createQuery(
				"from Client as c where c.nom=:leNom and c.prenom=:lePrenom",
				Client.class
			);
			q.setParameter("leNom", nom);
			q.setParameter("lePrenom", prenom);
			
			log.debug("Chargement de la liste des clients par nom et prenom");
			log.debug("Chargement de la liste des clients nommés " + prenom + " " + nom + ".");
			
			return q.list();			
		} 
		catch (HibernateException e) {
			log.catching(Level.ERROR, e);
			throw new BanqueException("Erreur lors de la récupération des clients nommés "+ prenom + " " + nom + ".");
		}
	}

	public void modifierClient(Client client) throws BanqueException {
		try {
			sessionFactory.getCurrentSession().merge(client);
			log.debug("Modifications du client enregistrées.");
		} 
		catch (HibernateException e) {
			log.catching(Level.ERROR, e);
			throw new BanqueException("Erreur lors de la modification du client.");
		}
	}

}
