package fr.formation.banque.integration.dao;

import java.util.List;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import fr.formation.banque.integration.entity.Client;
import fr.formation.banque.integration.entity.Compte;
import fr.formation.banque.util.BanqueException;

public class HibernateCompteDAO implements CompteDAO {

	private static Logger log = LogManager.getLogger(HibernateCompteDAO.class);

	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	public void ajouterCompte(Compte compte) throws BanqueException {
		try {
			Session session = sessionFactory.getCurrentSession();
			
			if(!session.contains(compte.getClient()))
				session.refresh(compte.getClient());

			session.persist(compte);
			
			log.debug("Création du compte réussie.");
		} 
		catch (HibernateException e) {
			log.catching(Level.ERROR, e);
			throw new BanqueException("Erreur lors de l'ajout du compte.");
		}
	}

	public void modifierCompte(Compte compte) throws BanqueException {
		try {
			sessionFactory.getCurrentSession().merge(compte);	
			log.debug("Modification du compte réussie.");
		} 
		catch (HibernateException e) {
			log.catching(Level.ERROR, e);
			throw new BanqueException("Erreur lors de la modification du compte.");
		}
	}

	public void supprimerCompte(Compte compte) throws BanqueException {
		try {
			sessionFactory.getCurrentSession().delete(compte);
			
			log.debug("Suppression du compte réussie.");
		} 
		catch (HibernateException e) {
			log.catching(Level.ERROR, e);
			throw new BanqueException("Erreur lors de la suppression du compte.");
		}
	}

	public Compte rechercherCompteParNumero(long numero) throws BanqueException {
		try {
			return sessionFactory.getCurrentSession().load(Compte.class, numero);
		}
		catch (HibernateException e) {
			log.catching(Level.ERROR, e);
			throw new BanqueException("Erreur de récupération du compte.");
		}
	}

	public List<Compte> rechercherComptesClient(Client client) throws BanqueException {
		try {
			Query<Compte> query = sessionFactory.getCurrentSession().createQuery(
				"from Compte as c where c.client=:leClient", Compte.class
			);
			
			query.setParameter("leClient", client);
			
			log.debug("Recherche des comptes pour le client " + client.getPrenom() + " " + client.getNom() + ".");
			
			return query.list();
		}
		catch (HibernateException e) {
			log.catching(Level.ERROR, e);
			throw new BanqueException("Erreur de récupération de la liste des comptes du client.");
		}
	}

	public List<Compte> rechercherComptesDebiteurs() throws BanqueException {
		try {
			Query<Compte> query = sessionFactory.getCurrentSession().createQuery(
				"from Compte as c where c.solde < 0", Compte.class
			);
			
			log.debug("Chargement des comptes débiteurs.");
			
			return query.list();
		} 
		catch (HibernateException e) {
			log.catching(Level.ERROR, e);
			throw new BanqueException("Erreur de récupération de la liste des comptes débiteurs.");
		}
	}

}
