package fr.formation.banque.metier;

import java.util.List;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import fr.formation.banque.integration.dao.ClientDAO;
import fr.formation.banque.integration.dao.CompteDAO;
import fr.formation.banque.integration.dao.HibernateCompteDAO;
import fr.formation.banque.integration.entity.Client;
import fr.formation.banque.integration.entity.Compte;
import fr.formation.banque.util.BanqueException;

public class BanqueServiceImpl implements BanqueService {

	private static Logger log = LogManager.getLogger(BanqueServiceImpl.class);
	
	private CompteDAO compteDAO;
	private ClientDAO clientDAO;
	
	public void setCompteDAO(CompteDAO compteDAO) {
		this.compteDAO = compteDAO;
	}

	public void setClientDAO(ClientDAO clientDAO) {
		this.clientDAO = clientDAO;
	}

	public Client authentifier(long id, String motDePasse) throws BanqueException {
		try {
			Client client = clientDAO.rechercherClientParId(id);
			if(client.getMotDePasse().equals(motDePasse)) {
				log.debug("Authentification avec " + id + "/" + motDePasse);
				return client;
			}
			else
				throw new BanqueException();
		} 
		catch (BanqueException e) {
			log.catching(Level.WARN, e);
			throw new BanqueException("Erreur d'authentification.");
		}
	}

	public List<Compte> mesComptes(long idclient) throws BanqueException {
		log.info("Récupération des comptes pour le client " + idclient + ".");
		Client client = clientDAO.rechercherClientParId(idclient);
		return compteDAO.rechercherComptesClient(client);
	}

	public void virementEntreComptes(
		long numeroCompteADebiter, long numeroCompteACrediter, double montant
	) throws BanqueException {
		try {
			Compte compteADebiter = compteDAO.rechercherCompteParNumero(numeroCompteADebiter);
			Compte compteACrediter = compteDAO.rechercherCompteParNumero(numeroCompteACrediter);
			
			compteADebiter.setSolde(compteADebiter.getSolde() - montant);
			compteACrediter.setSolde(compteACrediter.getSolde() + montant);
			
			compteDAO.modifierCompte(compteADebiter);
			compteDAO.modifierCompte(compteACrediter);
			
			log.debug("Enregistrement d'un virement du compte " + 
					  numeroCompteADebiter + " vers le compte " + 
					  numeroCompteACrediter + ", pour un montant de " + montant + " �.");
		} 
		catch (BanqueException e) {
			log.catching(Level.FATAL, e);
			throw new BanqueException("Erreur lors de l'enregistrement du virement.");
		}
	}

}
