package fr.formation.banque.presentation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import fr.formation.banque.integration.entity.Client;
import fr.formation.banque.integration.entity.Compte;
import fr.formation.banque.metier.BanqueService;

@Controller
@SessionAttributes({ "leClient" })
public class VirementController {

	// Injection du service m�tier 'banqueService'
	@Autowired
	@Qualifier("banqueService")
	private BanqueService banqueService;


	// M�thode d'affichage du formulaire
	// - Invoqu�e en GET
	// - Retourne l'identifiant de la vue de formulaire
	@RequestMapping(value = "/virement.do", method = RequestMethod.GET)
	public String showForm(
		@ModelAttribute("leClient") Client client, 
		ModelMap model
	) {
		try {
			if (client != null) {
				List<Compte> listeComptes = banqueService.mesComptes(client.getId());
				model.addAttribute("listeComptes", listeComptes);
				return "virement";
			}
			else {
				return "identification";
			} 
		}
		catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			return "erreur";
		}
	}

	// M�thode d'initialisation du bean de formulaire
	// - Annot�e avec @ModelAttribute contenant l'id du bean de formulaire
	// - Retourne une instance de ce bean
	@ModelAttribute("virementForm")
	public VirementForm initForm() {
		return new VirementForm();
	}

	// M�thode de traitement du formulaire
	// - G�r�e en POST
	// - Poss�de un param�tre du type du bean de formulaire, annot� avec
	// @ModelAttribute
	@RequestMapping(method = RequestMethod.POST)
	public String submitForm(
		@ModelAttribute("virementForm") VirementForm form,
		@ModelAttribute("leClient") Client client, 
		ModelMap model
	) {
		try {
			if (client != null) {
				// Virement
				banqueService.virementEntreComptes(
					Long.parseLong(form.getDebiter()),
					Long.parseLong(form.getCrediter()), 
					Double.parseDouble(form.getMontant())
				);

				
				// Liste des comptes � jour
				List<Compte> listeDesComptes = banqueService.mesComptes(client.getId());

				// Stockage des donn�es du mod�le dans le ModelMap pour la vue
				model.addAttribute("leClient", client);
				model.addAttribute("lesComptes", listeDesComptes);

				return "comptes";
			} 
			else {
				return "identification";
			}
		} 
		catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("message", e.getMessage());
			return "erreur";
		}
	}
}
