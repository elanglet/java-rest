package fr.formation.banque.integration.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Proxy;

@Entity
@Table(name="compte")
@Inheritance(strategy=InheritanceType.JOINED)
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
public class Compte {

	// Pas de @GeneratedValue, la valeur est assign�e par l'application
	@Id
	private long numero;
	
	@Column(name="solde", precision=10, scale=2)
	private double solde;

	// ASSOCIATION AVEC Client !
	// Surtout pas de : private long idClient
	@ManyToOne(cascade=CascadeType.PERSIST)
	@JoinColumn(name="idclient")
	private Client client;

	public Compte() { }

	public long getNumero() {
		return numero;
	}

	public void setNumero(long numero) {
		this.numero = numero;
	}

	public double getSolde() {
		return solde;
	}

	public void setSolde(double solde) {
		this.solde = solde;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

}
