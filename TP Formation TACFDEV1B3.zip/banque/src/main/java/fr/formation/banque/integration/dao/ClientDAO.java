package fr.formation.banque.integration.dao;

import java.util.List;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import fr.formation.banque.integration.entity.Client;
import fr.formation.banque.util.BanqueException;

public interface ClientDAO {

	@Transactional(value=TxType.REQUIRED, rollbackOn = BanqueException.class)
	public abstract void ajouterClient(Client client) throws BanqueException;
	
	@Transactional(value=TxType.REQUIRED, rollbackOn = BanqueException.class)
	public abstract Client rechercherClientParId(long id) throws BanqueException;
	
	@Transactional(value=TxType.REQUIRED, rollbackOn = BanqueException.class)
	public abstract List<Client> rechercherTousLesClients() throws BanqueException;
	
	@Transactional(value=TxType.REQUIRED, rollbackOn = BanqueException.class)
	public abstract List<Client> rechercherClientsParNomEtPrenom(String nom, String prenom) throws BanqueException;
	
	@Transactional(value=TxType.REQUIRED, rollbackOn = BanqueException.class)
	public abstract void modifierClient(Client client) throws BanqueException;
	
}
