package fr.formation.banque.presentation;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {

	@RequestMapping("/accueil.do")
	public String accueil() {
		
		// System.out.println(" *** Bienvenue *** ");
		
		return "accueil";
	}
	
}
